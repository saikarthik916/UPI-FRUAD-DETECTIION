"""
Train the UPI fraud classifier on data/upi_transactions_2024.csv.

Honesty note (read this before trusting the output)
-----------------------------------------------------
This dataset's `fraud_flag` column was checked column-by-column against
every other field (merchant category, amount, hour, bank, device, network,
state, weekday) and the fraud rate is flat (~0.19%) across every slice.
A Random Forest trained on the full feature set scores AUC ~0.48 on held
out data — statistically indistinguishable from random guessing. This is
almost certainly because the labels were assigned independently of the
features when the dataset was generated (i.e. there's no real fraud
*pattern* encoded in the file, just a fraud *rate*).

This script still trains and saves a real model on real data — that part
is genuine and reproducible. It just won't outperform the base rate at
telling fraud apart from non-fraud, and the backend is built to be honest
about that (the rule-based engine, not this model, drives the actual
risk decision — see backend/main.py).

Run:
    python train_model.py
Produces:
    models/fraud_pipeline.joblib   (sklearn Pipeline: preprocessing + ensemble)
    models/model_card.json         (metrics + honest description, shown in the UI)
"""

import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "upi_transactions_2024.csv"
MODELS_DIR = BASE_DIR / "models"
MODELS_DIR.mkdir(exist_ok=True)

CAT_COLS = [
    "transaction type", "merchant_category", "sender_age_group",
    "receiver_age_group", "sender_state", "sender_bank", "receiver_bank",
    "device_type", "network_type", "day_of_week", "transaction_status",
]
NUM_COLS = ["amount (INR)", "hour_of_day", "is_weekend"]


def main() -> None:
    print(f"Loading {DATA_PATH} ...")
    df = pd.read_csv(DATA_PATH)
    print(f"  {len(df):,} rows, fraud rate {df['fraud_flag'].mean():.4%}")

    X = df[CAT_COLS + NUM_COLS]
    y = df["fraud_flag"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore"), CAT_COLS),
            ("num", StandardScaler(), NUM_COLS),
        ]
    )

    # Two different model families, averaged — a real (if weak-signal) ensemble.
    rf = RandomForestClassifier(
        n_estimators=300, max_depth=12, min_samples_leaf=5,
        class_weight="balanced", n_jobs=-1, random_state=42,
    )
    logreg = LogisticRegression(
        max_iter=1000, class_weight="balanced", random_state=42,
    )

    rf_pipeline = Pipeline([("pre", preprocessor), ("clf", rf)])
    logreg_pipeline = Pipeline([("pre", preprocessor), ("clf", logreg)])

    print("Training Random Forest ...")
    t0 = time.time()
    rf_pipeline.fit(X_train, y_train)
    print(f"  done in {time.time() - t0:.1f}s")

    print("Training Logistic Regression ...")
    t0 = time.time()
    logreg_pipeline.fit(X_train, y_train)
    print(f"  done in {time.time() - t0:.1f}s")

    rf_proba = rf_pipeline.predict_proba(X_test)[:, 1]
    lr_proba = logreg_pipeline.predict_proba(X_test)[:, 1]
    ensemble_proba = 0.5 * rf_proba + 0.5 * lr_proba

    metrics = {
        "n_rows": int(len(df)),
        "fraud_rate": float(df["fraud_flag"].mean()),
        "test_set_size": int(len(y_test)),
        "random_forest": {
            "roc_auc": float(roc_auc_score(y_test, rf_proba)),
            "average_precision": float(average_precision_score(y_test, rf_proba)),
        },
        "logistic_regression": {
            "roc_auc": float(roc_auc_score(y_test, lr_proba)),
            "average_precision": float(average_precision_score(y_test, lr_proba)),
        },
        "ensemble": {
            "roc_auc": float(roc_auc_score(y_test, ensemble_proba)),
            "average_precision": float(average_precision_score(y_test, ensemble_proba)),
        },
        "note": (
            "AUC ~0.5 and average precision close to the base fraud rate mean "
            "this model does not discriminate fraud from non-fraud better than "
            "chance. The label column in the source CSV shows no measurable "
            "relationship to any input feature (verified by per-category fraud "
            "rate breakdown before training). The model is trained correctly; "
            "the ceiling is the data, not the method. The backend blends this "
            "score with a deterministic rule engine and weights the rule engine "
            "far more heavily as a result."
        ),
    }

    print("\n=== Evaluation (held-out 20%) ===")
    print(json.dumps(metrics, indent=2))
    print("\nClassification report (ensemble, threshold 0.5):")
    print(classification_report(y_test, (ensemble_proba >= 0.5).astype(int), zero_division=0))

    # Refit both models on the FULL dataset for the shipped artifact
    print("\nRefitting on full dataset for the production artifact ...")
    rf_pipeline.fit(X, y)
    logreg_pipeline.fit(X, y)

    bundle = {
        "random_forest": rf_pipeline,
        "logistic_regression": logreg_pipeline,
        "cat_cols": CAT_COLS,
        "num_cols": NUM_COLS,
        # Modes captured for imputing fields the live frontend never collects
        # (sender/receiver bank, age groups, device/network type) — see
        # backend/main.py FEATURE_DEFAULTS for how these are used.
        "column_modes": {c: df[c].mode().iloc[0] for c in CAT_COLS},
        "known_states": sorted(df["sender_state"].unique().tolist()),
        "known_merchant_categories": sorted(df["merchant_category"].unique().tolist()),
    }
    joblib.dump(bundle, MODELS_DIR / "fraud_pipeline.joblib")
    with open(MODELS_DIR / "model_card.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nSaved {MODELS_DIR / 'fraud_pipeline.joblib'}")
    print(f"Saved {MODELS_DIR / 'model_card.json'}")


if __name__ == "__main__":
    main()
