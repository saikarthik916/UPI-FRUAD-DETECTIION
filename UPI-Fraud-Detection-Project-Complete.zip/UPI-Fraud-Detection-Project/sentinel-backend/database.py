"""
Database layer — SQLite by default, one-line swap to PostgreSQL later.

To move to Postgres: set the SENTINEL_DATABASE_URL environment variable to
something like postgresql://user:password@host:5432/sentinel — nothing
else in this file or in main.py needs to change, since everything goes
through SQLAlchemy's engine/session abstraction rather than raw SQLite
calls.
"""

import os
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.environ.get(
    "SENTINEL_DATABASE_URL",
    "sqlite:///./sentinel.db",
)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Transaction(Base):
    """Every transaction ever scored by /predict, persisted server-side.

    This is the real database the frontend was missing — previously all
    history lived only in the browser's localStorage, which meant it
    vanished on a cache clear and was invisible to anyone else. Every
    prediction now lands here first.
    """

    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    transaction_id = Column(String, index=True, nullable=False)
    upi_id = Column(String, nullable=True)
    merchant = Column(String, nullable=False)
    location = Column(String, nullable=False)
    amount = Column(Float, nullable=False)
    hour = Column(Integer, nullable=False)

    risk_score = Column(Float, nullable=False)      # 0-1
    risk_level = Column(String, nullable=False)      # low | medium | high
    decision = Column(String, nullable=False)        # ALLOW | REVIEW | BLOCK
    confidence = Column(Float, nullable=False)        # 0-1
    ml_score = Column(Float, nullable=True)            # raw ensemble ML probability, informational
    rule_score = Column(Float, nullable=False)         # deterministic rule-engine score

    created_at = Column(DateTime, default=datetime.utcnow, index=True)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
