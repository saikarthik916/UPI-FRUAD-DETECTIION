"""
Sentinel — UPI Fraud Guard backend.

Implements exactly the API contract the existing frontend
(frontend/script.js) already calls:

  POST /predict
    body: { transaction_id, upi_id, merchant_id, amount, hour, location,
            device_risk_score, location_risk_score, user_behavior_score }
    returns: { risk_score (0-1), risk_level, decision, confidence (0-1),
               risk_factors: { amount, location, merchant, time } }

  GET /health
    returns 200 when the service (and its model) is up.

No frontend changes were needed — the frontend was already written
correctly against this contract. What was missing was a real backend
implementing it, and a real database instead of only browser localStorage.

Scoring approach
-----------------
Every prediction blends two things:
  1. A deterministic, transparent RULE ENGINE (amount tiers, odd hours,
     unfamiliar merchants, and the risk scores the frontend itself already
     computes client-side and sends along). This is the real signal.
  2. An ML ensemble (Random Forest + Logistic Regression) trained on
     backend/data/upi_transactions_2024.csv via train_model.py.

Important: that CSV's fraud_flag label was verified (see train_model.py's
docstring) to carry no measurable signal relative to any feature — AUC
~0.5 on held-out data. So the ML score is surfaced for transparency but
weighted lightly (15%) versus the rule engine (85%) in the final decision,
rather than pretending it's the primary detector.

Every request is persisted to SQLite (see database.py) so history survives
across devices/sessions, unlike the browser-only localStorage this project
had before.
"""

from __future__ import annotations

import logging
import re
import time
import warnings
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import joblib
import pandas as pd
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from database import Transaction, get_db, init_db

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("sentinel-backend")

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "fraud_pipeline.joblib"

# ---------------------------------------------------------------------------
# Merchant-category keyword mapping (frontend sends free-text merchant name;
# the trained model expects one of the 10 categories from the CSV).
# ---------------------------------------------------------------------------
MERCHANT_KEYWORDS = {
    "Food": ["swiggy", "zomato", "food", "restaurant", "cafe", "eat", "dine", "pizza", "burger"],
    "Shopping": ["amazon", "flipkart", "myntra", "meesho", "nykaa", "tatacliq", "shop", "store", "mart"],
    "Transport": ["uber", "ola", "irctc", "rapido", "metro", "cab", "taxi", "train", "bus", "fuel", "petrol"],
    "Utilities": ["airtel", "jio", "electricity", "water", "gas", "broadband", "utility", "bill"],
    "Entertainment": ["netflix", "hotstar", "spotify", "bookmyshow", "movie", "cinema", "game"],
    "Grocery": ["bigbasket", "grocery", "blinkit", "zepto", "dmart", "grofers", "supermarket"],
    "Healthcare": ["pharmacy", "hospital", "clinic", "apollo", "medlife", "1mg", "health"],
    "Education": ["school", "college", "university", "course", "udemy", "byju", "tuition"],
    "Fuel": ["petrol", "diesel", "fuel", "indianoil", "hpcl", "bpcl"],
}

INDIAN_STATE_ALIASES = {
    "bangalore": "Karnataka", "bengaluru": "Karnataka", "mysore": "Karnataka",
    "mumbai": "Maharashtra", "pune": "Maharashtra", "nagpur": "Maharashtra",
    "delhi": "Delhi", "new delhi": "Delhi",
    "hyderabad": "Telangana", "warangal": "Telangana",
    "chennai": "Tamil Nadu", "coimbatore": "Tamil Nadu", "madurai": "Tamil Nadu",
    "kolkata": "West Bengal", "howrah": "West Bengal",
    "ahmedabad": "Gujarat", "surat": "Gujarat", "vadodara": "Gujarat",
    "jaipur": "Rajasthan", "udaipur": "Rajasthan", "jodhpur": "Rajasthan",
    "lucknow": "Uttar Pradesh", "kanpur": "Uttar Pradesh", "noida": "Uttar Pradesh",
    "amaravati": "Andhra Pradesh", "visakhapatnam": "Andhra Pradesh", "vizag": "Andhra Pradesh",
}


def resolve_state(location: str, known_states: List[str]) -> Optional[str]:
    loc = location.strip().lower()
    for state in known_states:
        if state.lower() == loc:
            return state
    if loc in INDIAN_STATE_ALIASES:
        return INDIAN_STATE_ALIASES[loc]
    for city, state in INDIAN_STATE_ALIASES.items():
        if city in loc:
            return state
    for state in known_states:
        if state.lower() in loc:
            return state
    return None  # unknown -> let the encoder treat as "unseen category"


def resolve_merchant_category(merchant: str, known_categories: List[str]) -> Optional[str]:
    text = merchant.strip().lower()
    for category, keywords in MERCHANT_KEYWORDS.items():
        if category in known_categories and any(k in text for k in keywords):
            return category
    return None


# ---------------------------------------------------------------------------
# Model bundle
# ---------------------------------------------------------------------------
class ModelBundle:
    def __init__(self) -> None:
        self.loaded = False
        self.error: Optional[str] = None
        self.rf_pipeline = None
        self.lr_pipeline = None
        self.cat_cols: List[str] = []
        self.num_cols: List[str] = []
        self.column_modes: Dict[str, str] = {}
        self.known_states: List[str] = []
        self.known_merchant_categories: List[str] = []

    def load(self) -> None:
        try:
            bundle = joblib.load(MODEL_PATH)
            self.rf_pipeline = bundle["random_forest"]
            self.lr_pipeline = bundle["logistic_regression"]
            self.cat_cols = bundle["cat_cols"]
            self.num_cols = bundle["num_cols"]
            self.column_modes = bundle["column_modes"]
            self.known_states = bundle["known_states"]
            self.known_merchant_categories = bundle["known_merchant_categories"]
            self.loaded = True
            logger.info("Loaded fraud_pipeline.joblib (%s categorical, %s numeric features)",
                        len(self.cat_cols), len(self.num_cols))
        except Exception as exc:  # noqa: BLE001
            self.error = str(exc)
            logger.warning("Could not load model bundle: %s", exc)

    def build_row(self, amount: float, hour: int, merchant: str, location: str) -> pd.DataFrame:
        now = datetime.utcnow()
        day_name = now.strftime("%A")
        is_weekend = 1 if day_name in ("Saturday", "Sunday") else 0

        state = resolve_state(location, self.known_states) or self.column_modes.get("sender_state")
        category = resolve_merchant_category(merchant, self.known_merchant_categories) or self.column_modes.get("merchant_category")

        row = {
            "transaction type": self.column_modes.get("transaction type", "P2M"),
            "merchant_category": category,
            "sender_age_group": self.column_modes.get("sender_age_group"),
            "receiver_age_group": self.column_modes.get("receiver_age_group"),
            "sender_state": state,
            "sender_bank": self.column_modes.get("sender_bank"),
            "receiver_bank": self.column_modes.get("receiver_bank"),
            "device_type": self.column_modes.get("device_type"),
            "network_type": self.column_modes.get("network_type"),
            "day_of_week": day_name,
            "transaction_status": "SUCCESS",
            "amount (INR)": amount,
            "hour_of_day": hour,
            "is_weekend": is_weekend,
        }
        return pd.DataFrame([row])[self.cat_cols + self.num_cols]

    def predict_proba(self, amount: float, hour: int, merchant: str, location: str) -> Optional[float]:
        if not self.loaded:
            return None
        try:
            X = self.build_row(amount, hour, merchant, location)
            rf_p = float(self.rf_pipeline.predict_proba(X)[0, 1])
            lr_p = float(self.lr_pipeline.predict_proba(X)[0, 1])
            return 0.5 * rf_p + 0.5 * lr_p
        except Exception as exc:  # noqa: BLE001
            logger.warning("ML scoring failed: %s", exc)
            return None


model_bundle = ModelBundle()

# ---------------------------------------------------------------------------
# Request / response schemas — field names match the frontend exactly
# ---------------------------------------------------------------------------
class PredictRequest(BaseModel):
    transaction_id: Optional[str] = None
    upi_id: Optional[str] = "user@upi"
    merchant_id: str = Field(..., min_length=1, max_length=200)
    amount: float = Field(..., gt=0, le=10_000_000)
    hour: int = Field(..., ge=0, le=23)
    location: str = Field(..., min_length=1, max_length=200)
    device_risk_score: float = Field(default=0.1, ge=0, le=1)
    location_risk_score: float = Field(default=0.1, ge=0, le=1)
    user_behavior_score: float = Field(default=0.1, ge=0, le=1)


class PredictResponse(BaseModel):
    transaction_id: str
    risk_score: float          # 0-1
    risk_level: str            # low | medium | high
    decision: str              # ALLOW | REVIEW | BLOCK
    confidence: float          # 0-1
    risk_factors: Dict[str, float]
    ml_score: Optional[float]
    rule_score: float
    model_note: str
    timestamp: str


# ---------------------------------------------------------------------------
# Rule engine — the actual decision driver, fully transparent
# ---------------------------------------------------------------------------
_sanitize_re = re.compile(r"[<>\"'`;]")


def sanitize_text(value: str) -> str:
    """Strip characters with no legitimate place in a merchant/location
    name, as basic defense-in-depth against injection via free-text
    fields (on top of parameterised SQL from the ORM, which is the real
    protection)."""
    return _sanitize_re.sub("", value).strip()[:200]


def amount_risk(amount: float) -> float:
    if amount <= 1000:
        return 0.06
    if amount <= 5000:
        return 0.16
    if amount <= 20000:
        return 0.34
    if amount <= 50000:
        return 0.55
    if amount <= 100000:
        return 0.74
    return 0.92


def time_risk(hour: int) -> float:
    if 0 <= hour < 5:
        return 0.62
    if 5 <= hour < 9:
        return 0.22
    if 9 <= hour < 21:
        return 0.10
    return 0.36


def compute_rule_score(req: PredictRequest) -> Dict[str, float]:
    return {
        "amount": amount_risk(req.amount),
        "location": max(req.location_risk_score, 0.08),
        "merchant": max(req.user_behavior_score, 0.05),
        "time": time_risk(req.hour),
        "device": req.device_risk_score,
    }


def combine_rule_factors(factors: Dict[str, float]) -> float:
    return (
        factors["amount"] * 0.32
        + factors["location"] * 0.20
        + factors["merchant"] * 0.20
        + factors["time"] * 0.14
        + factors["device"] * 0.14
    )


def level_and_decision(score_pct: float, high_threshold: float = 80, medium_threshold: float = 50) -> tuple[str, str]:
    if score_pct >= high_threshold:
        return "high", "BLOCK"
    if score_pct >= medium_threshold:
        return "medium", "REVIEW"
    return "low", "ALLOW"


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    model_bundle.load()
    yield


app = FastAPI(title="Sentinel — UPI Fraud Guard API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # the frontend is served from a different port (see frontend/server.py)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {
        "status": "healthy",
        "model_loaded": model_bundle.loaded,
        "model_error": model_bundle.error,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


@app.post("/predict", response_model=PredictResponse)
async def predict(req: PredictRequest, db: Session = Depends(get_db)) -> PredictResponse:
    merchant = sanitize_text(req.merchant_id)
    location = sanitize_text(req.location)
    if not merchant or not location:
        raise HTTPException(status_code=422, detail="merchant_id and location must be non-empty")

    factors = compute_rule_score(req)
    rule_score = combine_rule_factors(factors)
    ml_score = model_bundle.predict_proba(req.amount, req.hour, merchant, location)

    # Rule engine drives the decision (85%); the ML ensemble is folded in
    # lightly (15%) and shown transparently — see the module docstring for
    # why it isn't trusted as the primary signal on this dataset.
    if ml_score is not None:
        final_score = 0.85 * rule_score + 0.15 * ml_score
        model_note = "ML ensemble loaded but contributes only 15% weight — see /health and the model card for why."
    else:
        final_score = rule_score
        model_note = "ML model unavailable this request — scored using the rule engine only."

    final_score = max(0.0, min(1.0, final_score))
    score_pct = final_score * 100
    risk_level, decision = level_and_decision(score_pct)
    confidence = 0.85 if ml_score is not None else 0.75

    transaction_id = req.transaction_id or f"TXN{int(time.time() * 1000) % 100_000_000}"

    record = Transaction(
        transaction_id=transaction_id,
        upi_id=req.upi_id,
        merchant=merchant,
        location=location,
        amount=req.amount,
        hour=req.hour,
        risk_score=round(final_score, 4),
        risk_level=risk_level,
        decision=decision,
        confidence=confidence,
        ml_score=round(ml_score, 4) if ml_score is not None else None,
        rule_score=round(rule_score, 4),
    )
    db.add(record)
    db.commit()

    return PredictResponse(
        transaction_id=transaction_id,
        risk_score=round(final_score, 4),
        risk_level=risk_level,
        decision=decision,
        confidence=confidence,
        risk_factors={k: round(v, 4) for k, v in factors.items()},
        ml_score=round(ml_score, 4) if ml_score is not None else None,
        rule_score=round(rule_score, 4),
        model_note=model_note,
        timestamp=datetime.utcnow().isoformat() + "Z",
    )


@app.get("/transactions")
async def list_transactions(limit: int = 50, db: Session = Depends(get_db)) -> Dict[str, Any]:
    limit = max(1, min(limit, 500))
    rows = (
        db.query(Transaction)
        .order_by(Transaction.created_at.desc())
        .limit(limit)
        .all()
    )
    return {
        "transactions": [
            {
                "transaction_id": r.transaction_id,
                "merchant": r.merchant,
                "location": r.location,
                "amount": r.amount,
                "risk_score": r.risk_score,
                "risk_level": r.risk_level,
                "decision": r.decision,
                "created_at": r.created_at.isoformat() + "Z",
            }
            for r in rows
        ]
    }


@app.get("/stats")
async def stats(db: Session = Depends(get_db)) -> Dict[str, Any]:
    total = db.query(func.count(Transaction.id)).scalar() or 0
    by_level = dict(
        db.query(Transaction.risk_level, func.count(Transaction.id)).group_by(Transaction.risk_level).all()
    )
    since_24h = datetime.utcnow() - timedelta(hours=24)
    last_24h = db.query(func.count(Transaction.id)).filter(Transaction.created_at >= since_24h).scalar() or 0
    avg_risk = db.query(func.avg(Transaction.risk_score)).scalar() or 0.0

    return {
        "total_scored": total,
        "low_risk": by_level.get("low", 0),
        "medium_risk": by_level.get("medium", 0),
        "high_risk": by_level.get("high", 0),
        "last_24h": last_24h,
        "average_risk_score": round(float(avg_risk), 4),
        "model_loaded": model_bundle.loaded,
    }


@app.delete("/transactions")
async def clear_transactions(db: Session = Depends(get_db)) -> Dict[str, str]:
    db.query(Transaction).delete()
    db.commit()
    return {"status": "cleared"}


@app.get("/model-card")
async def model_card() -> Dict[str, Any]:
    import json
    card_path = BASE_DIR / "models" / "model_card.json"
    if not card_path.exists():
        raise HTTPException(status_code=404, detail="model_card.json not found — run train_model.py first")
    return json.loads(card_path.read_text())


if __name__ == "__main__":
    import uvicorn

    print("=" * 60)
    print(" Sentinel — UPI Fraud Guard API")
    print(" API:    http://127.0.0.1:8000")
    print(" Docs:   http://127.0.0.1:8000/docs")
    print(" Serve the frontend separately: cd ../frontend && python server.py")
    print("=" * 60)
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False, log_level="info")
