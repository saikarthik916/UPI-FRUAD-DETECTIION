# UPI Fraud Detection — Complete Project

Everything from your original upload is here, untouched, plus the working
backend I built (`sentinel-backend/`) wired to your existing frontend and
trained on your real dataset. This file is your map — read this first.

## Quick start — the part that actually works

```bash
# 1. Backend
cd sentinel-backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py
# → API running at http://127.0.0.1:8000, SQLite DB auto-created here

# 2. Frontend (separate terminal)
cd frontend
python server.py
# → opens http://localhost:3000 — Settings already points at the API above
```

That's the whole running system: real trained model, real rule engine,
real database, real dashboard UI — matching the "Sentinel" screenshot you
showed me.

## What's in this project, and which parts are real

| Path | What it is | Status |
|---|---|---|
| `sentinel-backend/` | **The working backend** — FastAPI, real ML model trained on your CSV, SQLite database, matches `frontend/`'s API contract exactly | ✅ Built and tested by me, use this |
| `frontend/` | The dashboard UI (Sidebar, Dashboard, Analyze Transaction, Analytics, AI Model, Alerts, Settings) | ✅ Already correct, unmodified — the bug was never here |
| `models/` | The original 5 `.pkl` files (Random Forest, XGBoost, LightGBM, Isolation Forest, Scaler) that ship with the repo | ⚠️ Real, trained artifacts, but the RF one has a scikit-learn version bug (see note below); not used by `sentinel-backend` |
| `simple_backend_api.py` | Original simple backend | ❌ Fakes fraud scores with `random.uniform(...)` — decorative, don't use |
| `advanced_fraud_detection_api.py`, `serving/models/*.py` (GNN, RL, federated learning, blockchain audit, multimodal) | "Advanced" AI modules | ❌ No trained weights anywhere in the repo — architecture code only, would run with random/untrained weights if invoked. Real code, but not a working model. |
| `dashboard/` | A separate React + Ant Design admin panel | ⚠️ Generic scaffold, doesn't match your actual "Sentinel" UI (that's `frontend/`) — untouched, unused |
| `streaming/`, `infra/`, `ops/`, `docker-compose*.yml`, `nginx.conf`, `*.service` files | Kafka/K8s/systemd/nginx infrastructure config | ⚠️ Config only, nothing to actually run against — no cluster, no deployed services |
| `docs/`, `*.md` status files | Original project documentation | ℹ️ Kept as-is for reference |
| `README.ORIGINAL.md` | The repo's original top-level README | ℹ️ Renamed so this file takes its place as the entry point |

## The model — read this before trusting it

`sentinel-backend/models/fraud_pipeline.joblib` was trained on the
`upi_transactions_2024.csv` you provided (250,000 real transactions, real
`fraud_flag` labels). I evaluated it properly — stratified split,
class-balanced training, held-out test set:

**AUC ≈ 0.50 — random-guess level.** I checked the fraud rate broken down
by every column (merchant category, amount, hour, bank, device, network,
weekday) both before and after training: it's flat at ~0.19% everywhere.
The label in this specific file isn't correlated with any feature, so no
model can beat chance on it — that's a property of the data, not a bug.
Full metrics: `sentinel-backend/models/model_card.json`, also served live
at `GET /model-card`.

Because of this, `sentinel-backend/main.py` makes the actual decision with
a transparent **rule engine** (amount, time of day, and the risk scores
your frontend already computes client-side), weighted 85%. The ML ensemble
is still run and shown for transparency at 15% weight. Swap in a dataset
where fraud actually correlates with features, rerun
`sentinel-backend/train_model.py`, and turn the ML weight back up in
`main.py` — it's a one-line change.

The original `models/*.pkl` files have a separate, unrelated issue: the
Random Forest was pickled on scikit-learn 1.3.0 and silently returns
corrupted probabilities on newer scikit-learn versions. `sentinel-backend`
doesn't use these files at all (it has its own freshly-trained pipeline),
so this doesn't affect it — noted here only because those files are still
sitting in `models/` if you ever go looking.

## Database

SQLite, auto-created at `sentinel-backend/sentinel.db` on first run via
SQLAlchemy. Every transaction scored through `/predict` is persisted —
this replaces the old behavior where history only lived in the browser's
`localStorage`.

To move to PostgreSQL later, no code changes needed — just set:
```bash
export SENTINEL_DATABASE_URL="postgresql://user:password@host:5432/sentinel"
```

## Security notes

- All request fields validated by Pydantic — bad input gets a clean `422`.
- Free-text fields (merchant, location) sanitized before storage/display.
- All DB access goes through SQLAlchemy's ORM (parameterized queries) —
  not raw SQL string-building, so standard SQL injection isn't possible.
- CORS is open (`allow_origins=["*"]`) for local dev across the two ports
  (`:3000` frontend, `:8000` backend). Restrict this in `main.py` before
  deploying anywhere public.
- `sentinel.db` lives in `sentinel-backend/`, never in `frontend/`, so the
  static frontend server never serves it over HTTP.
